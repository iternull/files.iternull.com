MCU: ESP8266EX
Flash memory: 1MB
App Name: ��΢�� / eWeLink
App Link: http://www.ewelink.cc/
