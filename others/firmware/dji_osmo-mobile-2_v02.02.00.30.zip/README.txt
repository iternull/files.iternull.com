MCU: 
Flash Size: 
RAM Size: 
App Name: DJI GO
App Link: https://play.google.com/store/apps/details?id=dji.pilot
Product Name: Osmo Mobile 2
Product Link: https://www.dji.com/cn/osmo-mobile-2