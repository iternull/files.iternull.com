MCU: ESP8266EX
Flash memory: 1MB
App Name: ��΢�� / eWeLink
App Link: http://www.ewelink.cc/
0x00000: boot.bin
0x01000: v1.5.5_user1.1024.new.2.bin
