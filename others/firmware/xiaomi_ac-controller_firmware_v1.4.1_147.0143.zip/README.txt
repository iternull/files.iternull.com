MCU: 
Flash Size: 
RAM Size: 
App Name: �׼�
App Link: https://home.mi.com/index.html
Product Name: �׼ҿյ�����
Product Link: https://www.mi.com/ac-controller/
