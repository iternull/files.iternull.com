MCU: ESP8266EX
Flash memory: 1MB
