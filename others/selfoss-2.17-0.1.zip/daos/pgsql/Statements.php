<?php

namespace daos\pgsql;

/**
 * PostgreSQL specific statements
 *
 * @copyright  Copyright (c) Tobias Zeising (http://www.aditu.de)
 * @license    GPLv3 (https://www.gnu.org/licenses/gpl-3.0.html)
 * @author     Alexandre Rossi <alexandre.rossi@gmail.com>
 */
class Statements extends \daos\mysql\Statements {
    /**
     * wrap insert statement to return id
     *
     * @param sql statement
     * @param sql params
     *
     * @return id after insert
     */
    public static function insert($query, $params) {
        $res = \F3::get('db')->exec("$query RETURNING id", $params);

        return $res[0]['id'];
    }

    /**
     * null first for order by clause
     *
     * @param column to concat
     * @param order
     *
     * @return full statement
     */
    public static function nullFirst($column, $order) {
        if ($order == 'DESC') {
            $nulls = 'LAST';
        } elseif ($order == 'ASC') {
            $nulls = 'FIRST';
        }

        return "$column $order NULLS $nulls";
    }

    /**
     * sum statement for boolean columns
     *
     * @param bool column to concat
     *
     * @return full statement
     */
    public static function sumBool($column) {
        return "SUM($column::int)";
    }

    /**
     * bool true statement
     *
     * @param column to check for truth
     *
     * @return full statement
     */
    public static function isTrue($column) {
        return "$column=true";
    }

    /**
     * bool false statement
     *
     * @param column to check for false
     *
     * @return full statement
     */
    public static function isFalse($column) {
        return "$column=false";
    }

    /**
     * check if CSV column matches a value.
     *
     * @param CSV column to check
     * @param value to search in CSV column
     *
     * @return full statement
     */
    public static function csvRowMatches($column, $value) {
        return "$value=ANY(string_to_array($column, ','))";
    }

    /**
     * Ensure row values have the appropriate PHP type. This assumes we are
     * using buffered queries (sql results are in PHP memory).
     *
     * @param rows array of associative array representing row results
     * @param expectedRowTypes associative array mapping columns to PDO types
     *
     * @return array of associative array representing row results having
     *         expected types
     */
    public function ensureRowTypes($rows, $expectedRowTypes) {
        return $rows; // pgsql returns correct PHP types
    }
}
