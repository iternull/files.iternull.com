// ==UserScript==
// @name        ニコニコ動画 動画を保存
// @name:ja     ニコニコ動画 動画を保存
// @namespace   http://userscripts.org/users/347021
// @id          niconico-video-get-file-uri-347021
// @version     2.5.0
// @description Gets the URL of the video file.
// @description:ja 動画ファイルに直接アクセスする URL を提供
// @match       http://www.nicovideo.jp/watch/*
// @exclude     http://www.nicovideo.jp/watch/*?*edit=owner*
// @exclude     http://www.nicovideo.jp/watch/*?*edit=comment*
// @match       http://flapi.nicovideo.jp/api/getflv/*?*niconico-video-get-file-uri-347021=on*
// @match       http://*.nicovideo.jp/smile?*niconico-video-get-file-uri-347021=on
// @run-at      document-end
// @grant       GM_registerMenuCommand
// @grant       GM_setValue
// @grant       GM_getValue
// @icon        data:image/vnd.microsoft.icon;base64,AAABAAEAMDAAAAEAIADXCwAAFgAAAIlQTkcNChoKAAAADUlIRFIAAAAwAAAAMAgGAAAAVwL5hwAAC55JREFUaIHtmX9sHNV2xz93ZnbX3o2zu/653sSOsQ3YIQFcx/DUQkmCQFB4f5CKB3p/QCOVVuIPGlX8aCKrClEtwCWJhBDKP61U/kA8+opQEaUEKQhMMMKBZyLHJU79o9gkThx77d21Z9c7O6d/7M5kl2zybIMrVXpf6WpnZ+6ce77nnHvOvXPhD/j/AwPQ1lE2QOM6yQdgC1C2DnJ1cobpAwT4x/UYIJAXLsCf/MzyvUA6LzvJ+hgJgGe4QuI3+XtrHcwJmacAOy/zSP6evlYFfx8UcBMwnh/wAtCUf7bSuaHyv2Hg3/NyZoB7VynnJ+PvueKNv17lu78qePeD/D117e7Xx1pe1Mi5vRH4D+AWoB/4Y8CTV8yR7bRloAb4GLg1//9u4KtSAzz22GOBb775pnZpaanasqwq27arbNsOWZYVjsfj9cBREfnvtRBwlHehlDoE/B3gEZFfAV97vV4CgUAgFosFAD9wq6ZpR23bTpGbN/9KLjF4gUqgGoh4PB5veXk5fr8fv99PIBBwm2EYlJeX8/HHH5umaV6ybbsJUKslYABvAnVAFbApP/iKcN9997Fjxw5aWlpobGxk06ZNbN68mY0bN67o/WeffZbDhw87k35FdUmRCwuAf/F6vQJIS0uLHDp0SN577z37xIkTVl9fn5w8eVLef/99CYfD9pYtW+y9e/fa5DNMR0eHJJNJKYVsNiuWZYllWZLNZt2WyWQkk8mIiEh3d7dUVlYKIOFwOKuUsvI6XZNAoWf+Std1ATK33HKL3d/f7w5umqaYpimpVEosy5KBgQGJRCLOBHXbsWPH5JVXXpHPP/+8JAkHtm2LZVkiIpJIJOTYsWMCSDAYlMcff1yGh4elp6cnS24OAWgG18afAp8opZSI8NFHHxn3339/UYeysitl4NKlSyil+OCDD5iammJwcJBAIEBDQwNbt25l69ataNrvz5K6rvPCCy/Q29uLx+Ph4MGDPPTQQyilWFpawu/3A2Sd/oUEVN5iNwK/VUrdKiL2oUOH1IEDBwCYmZlB0zREBNu2yWazblNKEQqFSKVStLa2cu+99+L1ekkmkyQSCYaHh1laWsI0TRKJhNvm5+eJxWJMT08zMjJCf38/IsJTTz3FM888g9/vp7m5mcHBQWzbxomGkuw1TXs5T8Ip7evalFKi67oYhiGGYQggHo9HAPnkk09kYGBAjh49KpqmSTQalbNnz8qRI0csYM5VmSvx/jvbtv+2t7cXy7K8tm0jIkUtm82yvLyMaZosLi66bWlpiXQ6TTabveqd6zXbtrEsi0wmQyaTIZVKkcnkjJtKpfjqq6949913SSaThEIhqqursW2bQg84qSjr8/lu37Vrlzz33HNks1kymQxer/fHHkLTNDweD2tBIpFwSadSKdLpNJZl0dLSQigUwufz8fzzz9Pb24vP58Pv99PW1sbrr7/Om2++yezsLI2NjUUhZOTdSTabTUaj0XJA13Wdvr4+Dh8+jIhQVlZGWVkZHo8HpZTriVQqxeLiIgsLC24sz8/Pu1ZcDdLpNEopNmzYAEAwGKSzs5Pdu3czOTlJNpslHo8zNzdHAQFxJ7Gu6zHTNMsApqam2LVrlys8Go3S2NhIfX09NTU1RCIRqqqqqKyspKqq6qprXV/5grKnp4fu7m7Gx8e5+eabXe96vV5SqRQzMzNF2W5xcVG4kkaveEDTtLlYLFYH8OGHHwIwODjIbbfdtmJlCrPTj6EKir6IuNdPP/003d3dTmy78Hq9pNNp938gEMCyLFKpFCUJiMh8IpEQgMbG3M5u27ZtZLPZFVtUKXXdvoWKOzXB6e9YXkTweDwYRnGJisfj3HTTTUSj0SIPFFaW87FYTAHceOONRcJ/LiiluHjxYpE3HMs7sW9ZFuFw+Kp3dV1ndHSUixcvUpKAiHx3+fJlL0BzczMApmm6gy0vL5cMjdVg37591NfXo2kas7OzAG6YBINBN1WHQiGam5uvCiuAZDJZ6AEpJDDiCHUwPj7uuvrbb79lfn7+JxEo9Oinn34K5IwEUF5e7hIIBoMAdHZ2FnkLcDJc0RxwHgw7AnRdp6amhpGREdra2ujr62Pnzp0O0TUpLyK8/PLLiAh33XUXe/bsKSIAuRDLZDIEg0FisRiTk5O0t7dz5swZdwmTzWadlQJQHEJnAL788ksAbr/9doaGhtA0rSiNrRVKKQzD4MiRI+zZs8cNj6WlpaI+y8vLBINBwuEwLS0trg5KKVpaWrAsSyP39aKYAPkVXl9fHwAdHR18/fXXANx555388MMPiAiWZbFW2LbN3NwcCwsLbuwnk8miPplMhoqKCiCXOru6uvB4PIgIIyMjWJalKaUSpQgAjPf39wPQ1dXlkrl48SKVlZUAV6W3lUJESKfTjI+PMzo6yvj4OJBbXhTODcuy3Ix05swZ4vG4O6au61y4cEE3DGOhJAGl1DenTp0CYPPmzczOzjI0NMTExATT09NrUrxANn6/n+rqaizLcpVKJBIEAgG3XzqdJhgMMjU1RTAY5Ny5c5imiW3bBINBDMNQhmG42aTInB6P53fnz5//c4Dq6txWNx6P4/P5aGpqQkSuygoOrvesEFu2bCEajbp94/G4a3HIeSAWi5FMJkkmkyilEBE0TSMWi7G4uIjH41lwJn+hB3xKqdOO0JqaGgBqa2vZvn27a8VrYSXKOyistAsLC0UEUqkUN9xwA+Xl5UU7OIfEwsIChR4oJCDAeYBLly6Jk4uXl5e5HizL4rPPPqOjowNg1cUuFou5k9aRl0gkXMs7MnVdd6PAMIxYKQK2bdsXHAIAlZWVXLhw4bq5/+TJk9xzzz2cPXvWTYOrWU7Pzc0VETBNk0gkUlSFa2trqaioYGJiAk3T8Pl8pQlkMpnzAOfOnROAO+64gy+++AKfz3fVwJZlMTY2xs6dO1FKuQVp06ZNq9rwzM3NFX0XWl5eJh6Ps7CwUNQHcqndNE02bNhwuSQBp39/f7+CXP5/6aWXrlLc2T6Gw2F6enp48MEH2bZtG9FoFI/HwxtvvLFiAvPz8+7SAXJZqJQB5ubmGB0dRUTYvn37jHO/VFL/z76+vl8DPPzww7z44osopaivr2f37t3cfffdtLe3E41GCYfD7N+/f1UTuHCvrWka09PTdHZ2us9TqRQej6doLvn9fhKJBLZtMzk5yalTp5xNfUkC/zY8PPxrgB07dhCLxRgYGGBoaIjvvvuOd955h7GxMb7//vuiODUMg4aGBqLRKPX19UQiESKRCDU1NdTV1VFXV0dNTY0bz7Ztk06nGRoaYt++fa4c0zQxDINoNMrk5CSaphGPx6mtraWrq4vLly8XneD82HR6/l7m0UcflVdffVU5m5trIZPJEI/H3e898XiceDzO/Pw8ExMTjI+PMzY25lbfUlkqHo+7E7mpqYkDBw7wwAMP0NjYyPHjxzl48GCqv7+/TNO0R23b/m1ZWZlKpVJSioDz/3+UUptFxH0eDAbxer2EQiFqa2uJRqM0NDTQ3t5uNzU1EQqFCIfDhEIhla+YpeQXYXFxkUAgQCaTQdM0dF0nHA7z2muvEQqFeOutt+y3335b83q931uW9QvbtmeAosXYtQaoBt4CXgIMpdQ+Efmz/fv3Y5omp0+f5sSJE9fTDaUUzc3NtLe309bWRltbG62trbS2thKJRK6521NKUVVVRcHe5J+Av7zuYCvEe3v37hURkSeffNIiV/j+AairqKjwVlVVbQiHw3XBYLA5GAxu27hx453AbuCXwF8AzwGvAP8M/BdXzsYKPwhnlFICWPnfX+TH/slHT465hpqbm0XTtEvAH+XvOR/H9Py1Qe6TvBfwkTvQ8PAjbyulTiul7OPHj4uIyCOPPCLAPPA3wOv5butyYvmCo8NPkKGRI2g98cQTWRERTdPE5/P9kivnEesCxxM/12niJkACgYBomvbgzyTz/xQGubMyWGfL/wHrhf8Ft6Tp1QdndmIAAAAASUVORK5CYII=
// @compatible  Firefox
// @compatible  Opera
// @compatible  Chrome
// @author      100の人
// @homepage    https://greasyfork.org/scripts/269
// @contributor JixunMoe https://greasyfork.org/users/44
// @license     Mozilla Public License Version 2.0 (MPL 2.0); https://www.mozilla.org/MPL/2.0/
// ==/UserScript==

(function () {
'use strict';

polyfill();

// L10N
Gettext.setLocalizedTexts({
	'en': {
		'動画を保存': 'Video download',
		'停止する': 'Stop',
		'ページを更新し、ログインが切れていないかご確認ください。': 'Please reload and make sure whether you are still logged in or not (check if session has expired).',
		'プレイヤーを表示する場合は %s してください。': '',
		'ページを更新': '',
		'ファイル名に動画IDを付加する。': '',
	},
	'zh-TW': {
		'動画を保存': '動畫下載',
		'停止する': '停止',
		// Translation for chinese... - Greasy Forum <https://greasyfork.org/forum/discussion/62/translation-for-chinese-/p1>
		'ページを更新し、ログインが切れていないかご確認ください。': '請重新整理頁面檢查登入信息是否過期。',
		'プレイヤーを表示する場合は %s してください。': '',
		'ページを更新': '',
		'ファイル名に動画IDを付加する。': '',
	},
	// Translation for chinese... - Greasy Forum <https://greasyfork.org/forum/discussion/62/translation-for-chinese-/p1>
	'zh-CN': {
		'動画を保存': '动画下载',
		'停止する': '停止',
		'ページを更新し、ログインが切れていないかご確認ください。': '请刷新页面检查您的登录信息是否过期。',
		'プレイヤーを表示する場合は %s してください。': '',
		'ページを更新': '',
		'ファイル名に動画IDを付加する。': '',
	},
});



/**
 * 動画ファイルを解放するまでの時間 (分)。
 * @constant {number}
 */
var LIFEMINUTES_OF_VIDEO = 10;

/**
 * スクリプトを有効にするページのGETパラメータ等に使用するID。
 * 半角英数とハイフンのみからなる文字列。
 * @constant {string}
 */
var ID = 'niconico-video-get-file-uri-347021';

/**
 * 視聴ページの生成元。
 * @constant {string}
 */
var VIDEO_PAGE_ORIGIN = 'http://www.nicovideo.jp';

/**
 * APIサーバーの生成元。
 * @constant {string}
 */
var API_ORIGIN = 'http://flapi.nicovideo.jp';

/**
 * 動画サーバーの生成元に一致する正規表現。
 * @constant {RegExp}
 */
var VIDEO_SERVER_ORIGIN_REGEXP = /^http:\/\/smile-[a-z]+[0-9]+\.nicovideo\.jp$/;

/**
 * 分をミリ秒に変換するときの乗数。
 * @constant {number}
 */
var MINUTES_TO_MILISECONDS = 60 * 1000;

/**
 * ページのURL。
 * @type {string}
 */
var href = window.location.href;

if (document.URL === 'about:blank') {
	// window.location.origin参照時に発生するFirefoxのエラーを抑止
} else if (href.startsWith('http://www.nicovideo.jp/watch/')) {
	// 視聴ページ
	if (document.title !== 'ニコニコ動画:GINZA') {
		// 非公開でなければ
		main();
	}
} else if (href.startsWith('http://flapi.nicovideo.jp/api/getflv/') && new URLSearchParams(window.location.search.replace('?', '')).has(ID)) {
	// 動画情報API
	window.addEventListener('message', function (event) {
		if (event.origin === VIDEO_PAGE_ORIGIN) {
			var data = event.data;
			if (isDataToThisScript(data)) {
				// 親から動画サーバーへの接続指示が来たら
				var url = new URLSearchParams(document.body.textContent.trim()).get('url');
				if (url) {
					connectVideoServer(url, event.source);
				} else {
					// ログインしていなければ
					event.source.postMessage({
						id: ID,
						error: 'login',
					}, VIDEO_PAGE_ORIGIN);
				}
			}
		}
	});
} else if (VIDEO_SERVER_ORIGIN_REGEXP.test(window.location.origin) && window.location.pathname === '/smile' && new URLSearchParams(window.location.search.replace('?', '')).has(ID)) {
	// 動画ファイルサーバー
	window.addEventListener('message', function (event) {
		var data;
		if (event.origin === API_ORIGIN) {
			data = event.data;
			if (isDataToThisScript(data)) {
				// 親から動画ファイルへの接続指示が来たら
				openVideoFile(data.url);
			}
		}
	});
}

function main() {
	/**
	 * @property {Object}              shared
	 * @property {string}              shared.videoId  - 動画ID。一度でもスクリプトを実行していれば存在する。
	 * @property {string}              shared.title    - 動画のタイトル。
	 * @property {string}              shared.type     - 動画のMIMEタイプ。
	 * @property {HTMLIFrameElement}   shared.iframe   - 動画情報APIのページ。実行中に存在する。
	 * @property {HTMLProgressElement} shared.progress - 動画の読み込み状態を表示する要素。
	 * @property {HTMLButtonElement}   shared.button   - 読み込み停止ボタン。
	 * @property {boolean}             shared.fileNameWithVideoId - ファイル名に動画IDを付加するなら真。
	 */
	var shared = {};

	// メニュー項目の作成
	GM_registerMenuCommand(_('動画を保存'), function () {
		if (!shared.iframe) {
			// 実行中でなければ
			if (!shared.videoId) {
				// 動画ページを開いて最初の実行なら
				// プレイヤーのフルスクリーンを解除する
				executeOnUnsafeContext(function () {
					(document.getElementById('flvplayer') || PlayerApp.ns.player.Nicoplayer.getInstance().getExternalNicoplayer()).ext_setVideoSize('normal');
				});
				// ファイル名の設定を取得
				shared.fileNameWithVideoId = GM_getValue('fileNameWithVideoId', true);
				// 動画IDの取得
				shared.videoId = window.location.pathname.replace('/watch/', '');
				// 動画のタイトルを取得
				shared.title = convertSpecialCharacter((document.getElementById('video_title') || document.getElementsByClassName('videoHeaderTitle')[0]).textContent);
				// プレイヤーの親要素を取得
				var parent = document.getElementById('flvplayer_container') || document.getElementById('playerContainer');
				// 進捗情報を表すバー、停止ボタンなどを表示
				parent.innerHTML = '<progress value="0"></progress> \
					<button type="button" name="stop">' + h(_('停止する')) + '</button> \
					<p><label><input type="checkbox" name="with-video-id"' + (shared.fileNameWithVideoId ? 'checked=""' : '') + ' />'
							+ h(_('ファイル名に動画IDを付加する。')) + '</label></p>\
					<p>' + h(_('プレイヤーを表示する場合は %s してください。'))
							.replace('%s', '<button type="button" name="reload">' + h(_('ページを更新')) + '</button>') + '</p>';
				shared.progress = parent.getElementsByTagName('progress')[0];
				shared.button = parent.querySelector('[name="stop"]');
				parent.addEventListener('click', function (event) {
					var target = event.target;
					if (target.localName === 'button') {
						switch (target.name) {
							case 'stop':
								// 停止ボタン
								stopScript();
								break;
							case 'reload':
								// 更新ボタン
								window.location.reload();
								break;
						}
					}
				});
				parent.querySelector('[name="with-video-id"]').addEventListener('change', function (event) {
					GM_setValue('fileNameWithVideoId', (shared.fileNameWithVideoId = event.target.checked));
				});
			} else {
				// 停止ボタンを有効化
				shared.button.disabled = false;
			}
			// ページを再読み込み
			var client = new XMLHttpRequest();
			client.open('GET', document.URL);
			client.addEventListener('load', function () {
				// 動画サーバーからのメッセージ待ち受け
				window.addEventListener('message', receiveMessage);
				executeOnUnsafeContext(addEventListenerReceivingBinary, [
					ID,
					VIDEO_SERVER_ORIGIN_REGEXP,
					LIFEMINUTES_OF_VIDEO * MINUTES_TO_MILISECONDS,
				])
				// 動画情報APIのページを埋め込み、動画サーバーへの接続を指示する
				shared.iframe = connectVideoInfoApi(shared.videoId);
			});
			client.send();
		}
	}, 's');

	/**
	 * API、動画サーバーからのメッセージを受け取るイベントリスナー。
	 * @param {MessageEvent} messageEvent
	 */
	function receiveMessage(messageEvent) {
		var data;
		if (messageEvent.origin === API_ORIGIN) {
			// APIからのメッセージ
			data = messageEvent.data;
			if (isDataToThisScript(data)) {
				if (data.error === 'login') {
					// ログインしていなければ
					reportLoginError();
				}
			}
		} else if (VIDEO_SERVER_ORIGIN_REGEXP.test(messageEvent.origin)) {
			// 動画サーバーからのメッセージ
			data = messageEvent.data;
			if (isDataToThisScript(data)) {
				if (data.type) {
					// 動画の取得が完了していれば
					// スクリプトの終了処理
					shared.type = data.type;
				} else if (data.total) {
					// 進捗状況の通知なら
					shared.progress.max = data.total;
					shared.progress.value = data.loaded;
				} else if (data.error === 'login') {
					// ログインしていなければ
					reportLoginError();
				}
			}
		} else if (messageEvent.origin === VIDEO_PAGE_ORIGIN) {
			// 動画ページからのメッセージ
			data = messageEvent.data;
			if (isDataToThisScript(data)) {
				// Blob URLを受け取る
				clickURL(data.url, shared.title + (shared.fileNameWithVideoId ? ' (' + shared.videoId + ')' : '') + typeToExtension(shared.type));
				stopScript();
			}
		}
	}

	/**
	 * ページ側のコンテキストで実行する関数。
	 * @param {string} id - messageイベントで当スクリプトの通信を識別するためのID。
	 * @param {string} videoServerOriginPattern - 動画サーバーの生成元に一致する正規表現のソース。
	 * @param {number} timeout - Blob URLを破棄するまでのミリ秒数。
	 */
	function addEventListenerReceivingBinary(id, videoServerOriginPattern, timeout) {
		var videoServerOriginRegExp = new RegExp(videoServerOriginPattern);

		window.addEventListener('message', function receiveBinary(event) {
			if (videoServerOriginRegExp.test(event.origin)) {
				var data = event.data;
				if (typeof data === 'object' && data !== null && data.id === id && data.type) {
					/* メッセージイベントリスナーの削除 */
					window.removeEventListener('message', receiveBinary);
					/* ArrayBufferのBlobへの変換、Blob URLの生成 */
					var url = window.URL.createObjectURL(new Blob([data.arrayBuffer], {type: data.type}));
					/* Blob URLをGreasemonkeyスクリプトのコンテキストに送る */
					window.postMessage({id: id, url: url}, window.location.origin);
					/* 一定時間後、Blob URLに紐づく資源を解放 */
					window.setTimeout(window.URL.revokeObjectURL, timeout, url);
				}
			}
		});
	}

	/**
	 * a要素でURLを埋め込みクリックする。
	 * @param {string} url
	 * @param {string} title
	 */
	function clickURL(url, title) {
		var body = document.body;
		body.insertAdjacentHTML('beforeend', '<a href="' + url + '" download="' + h(title) + '" hidden=""></a>')
		var anchor = body.lastElementChild;
		anchor.click();
		anchor.remove();
	}

	/**
	 * {@link stopScript}を実行し、ログインを促す。
	 */
	function reportLoginError() {
		// スクリプトの実行を停止する
		stopScript();
		// 警告ダイアログを表示する
		window.alert(_('ページを更新し、ログインが切れていないかご確認ください。'));
	}

	/**
	 * スクリプトの実行を停止する (終了処理)。
	 */
	function stopScript() {
		// メッセージイベントリスナーの削除
		window.removeEventListener('message', receiveMessage);
		// 停止ボタンを無効化
		shared.button.disabled = true;
		// 埋め込んだAPIを削除することで実行を停止
		shared.iframe.remove();
		delete shared.iframe;
	}
}

/**
 * 当スクリプト宛てのメッセージなら真を返す。
 * @param {*} data - MessageEventインスタンスのdataプロパティ値。
 * @returns {boolean}
 */
function isDataToThisScript(data) {
	return typeof data === 'object' && data !== null && data.id === ID;
}

/**
 * 動画情報APIのページを埋め込み、動画サーバーへの接続を指示する。
 * @param {string} [videoId] - 動画ID。
 * @returns {HTMLIFrameElement} 埋め込んだフレーム。
 */
function connectVideoInfoApi(videoId) {
	var searchParams = new URLSearchParams(window.location.search.replace('?', ''));
	searchParams.set(ID, 'on');
	searchParams.set('as3', '1');
	var url = 'http://flapi.nicovideo.jp/api/getflv/' + videoId + '?' + searchParams;

	var body = document.body;
	body.insertAdjacentHTML('beforeend', '<iframe src="' + url + '" hidden=""></iframe>')
	var iframe = body.lastElementChild;
	iframe.addEventListener('load', function (event) {
		event.target.contentWindow.postMessage({
			id: ID,
		}, API_ORIGIN);
	});
	return iframe;
}

/**
 * 動画ファイルと同一オリジンのページを埋め込み、動画ファイルのURLを送信する。
 * @param {string} url - 動画ファイルのURL。
 */
function connectVideoServer(url) {
	var body = document.body;
	body.insertAdjacentHTML('beforeend', '<iframe src="' + url.split('?')[0] + '?' + ID + '=on' + '" hidden=""></iframe>')
	var iframe = body.lastElementChild;
	iframe.addEventListener('load', function (event) {
		event.target.contentWindow.postMessage({
			id: ID,
			url: url,
		}, /^(http:\/\/[^/]+)/.exec(url)[1]);
	});
}

/**
 * 動画ファイルを取得し、親の親（視聴ページ）に進捗状況を送信する。
 * @param {string} url - 動画ファイルのURL。
 */
function openVideoFile(url) {
	var client = new XMLHttpRequest(), videoPage = window.parent.parent;
	client.open('GET', url);
	client.responseType = 'arraybuffer';
	client.addEventListener('progress', function (event) {
		if (event.lengthComputable) {
			videoPage.postMessage({
				id: ID,
				total: event.total,
				loaded: event.loaded,
			}, VIDEO_PAGE_ORIGIN);
		}
	});
	client.addEventListener('load', function (event) {
		var target = event.target, message = { id: ID };
		if (target.status === 200) {
			message.arrayBuffer = target.response;
			message.type = correctMimeType(target.getResponseHeader('content-type'));
		} else {
			// 取得に失敗していればログインを促す
			message.error = 'login';
		}
		videoPage.postMessage(message, VIDEO_PAGE_ORIGIN);
	});
	client.send();
}

/**
 * MIMEタイプに対応する拡張子を返す。
 * @param {string} type - MIMEタイプ。
 * @returns {string} ピリオドを含む拡張子。
 */
function typeToExtension(type) {
	switch (type.toLowerCase()) {
		case 'video/mp4':
			return '.mp4';
		case 'video/x-flv':
			return '.flv';
		case 'application/x-shockwave-flash':
			return '.swf';
	}
	return '';
}

/**
 * MIMEタイプが間違っていれば正しいタイプを返す。
 * @param {string} type
 * @returns {string}
 */
function correctMimeType(type) {
	switch (type.toLowerCase()) {
		case 'video/flv':
			return 'video/x-flv';
	}
	return type;
}

/**
 * ファイル名に使用できないASCII記号を全角に変換する。
 * ただしWindowsにおいて、「AUX」等の完全一致した場合に使用できない文字列は置換しない。
 * @param {string} str
 * @returns {string}
 */
function convertSpecialCharacter(str) {
	str = str.replace(/[\x00-\x1F\x7F]+/g, '')	// 制御文字を削除
			.replace(/ {2,}/g, ' ')	// 連続する半角空白を1つに
			.replace(/^ | $/g, '')	// 先頭末尾の半角空白を削除
			.replace(/\/|^\./g, convertCharacterToFullwidth);	// スラッシュ、先頭のピリオドを全角に

	if (window.navigator.platform.toLowerCase().indexOf('win') !== -1
			|| window.navigator.userAgent.indexOf('Android') !== -1) {	// Firefox には String#includes が実装されていない
		// Windows、又はAndroidの場合
		str = str.replace(/[\\<>:"/|?*]/, convertCharacterToFullwidth);
	}

	return str;
}

/**
 * 半角空白を除く1文字のASCII印字可能文字を対応する全角文字に変換する。
 * ASCII印字可能文字以外と半角空白の入力は想定しない。
 * @param {string} character - 半角空白を除くASCII印字可能文字。
 * @returns {string}
 */
function convertCharacterToFullwidth(character) {
	/**
	 * UTF-16において、空白を除くASCII文字を対応する全角形に変換するときの加数
	 * @constant {string}
	 */
	var BETWEEN_HALF_AND_FULL = '～'.charCodeAt() - '~'.charCodeAt();

	return String.fromCharCode(character.charCodeAt() + BETWEEN_HALF_AND_FULL);
}



/**
 * {@link unsafeWindow}なコンテキストで関数を実行する。
 * @param {Function} func
 * @param {Array} [args]
 */
function executeOnUnsafeContext(func, args) {
	fixPrototypeJavaScriptFramework();
	var script = document.createElement('script');
	script.text = '(' + func.toString() + ').apply(null, ' + JSON.stringify(args || []) + ')';
	document.head.appendChild(script).remove();
}

/**
 * 挿入された節の親節が、目印となる節の親節か否かを返すコールバック関数。
 * @callback isTargetParent
 * @param {(Document|Element)} parent
 * @returns {boolean}
 */

/**
 * 挿入された節が、目印となる節か否かを返すコールバック関数。
 * @callback isTarget
 * @param {(DocumentType|Element)} target
 * @returns {boolean}
 */

/**
 * 目印となる節が文書に存在するか否かを返すコールバック関数。
 * @callback existsTarget
 * @returns {boolean}
 */

/**
 * 目印となる節が挿入された直後に関数を実行する。
 * @param {Function} main - 実行する関数。
 * @param {isTargetParent} isTargetParent
 * @param {isTarget} isTarget
 * @param {existsTarget} existsTarget
 * @param {Object} [callbacksForFirefox]
 * @param {isTargetParent} [callbacksForFirefox.isTargetParent] - Firefoxにおける{@link isTargetParent}。
 * @param {isTarget} [callbacksForFirefox.isTarget] - Firefoxにおける{@link isTarget}。
 * @param {number} [timeoutSinceStopParsingDocument=0] - DOM構築完了後に監視を続けるミリ秒数。
 * @version 2014-11-25
 * @global
 */
function startScript(main, isTargetParent, isTarget, existsTarget) {
	/**
	 * {@link checkExistingTarget}で{@link startMain}を実行する間隔（ミリ秒）。
	 * @constant {number}
	 */
	var INTERVAL = 10;
	/**
	 * {@link checkExistingTarget}で{@link startMain}を実行する回数。
	 * @constant {number}
	 */
	var LIMIT = 500;

	/**
	 * 実行済みなら真。
	 * @type {boolean}
	 */
	var alreadyCalled = false;

	// 指定した節が既に存在していれば、即実行
	startMain();
	if (alreadyCalled) {
		return;
	}

	// FirefoxのMutationObserverは、HTMLのDOM構築に関して要素をまとめて挿入したと見なすため、isTargetParent、isTargetを変更
	var callbacksForFirefox = arguments[4];
	if (callbacksForFirefox && typeof MozSettingsEvent !== 'undefined') {
		isTargetParent = callbacksForFirefox.isTargetParent || isTargetParent;
		isTarget = callbacksForFirefox.isTarget || isTarget;
	}

	var observer = new MutationObserver(mutationCallback);
	observer.observe(document, {
		childList: true,
		subtree: true,
	});

	var timeoutSinceStopParsingDocument = arguments[5] || 0;
	if (document.readyState === 'complete') {
		// DOMの構築が完了していれば
		onDOMContentLoaded();
	} else {
		document.addEventListener('DOMContentLoaded', onDOMContentLoaded);
	}

	/**
	 * {@link startMain}を実行し、スクリプトが開始されていなければさらに{@link timeoutSinceStopParsingDocument}ミリ秒待機し、
	 * スクリプトが開始されていなければ{@link stopObserving}を実行する。
	 */
	function onDOMContentLoaded() {
		startMain();
		if (timeoutSinceStopParsingDocument === 0) {
			if (!alreadyCalled) {
				stopObserving();
			}
		} else {
			window.setTimeout(function () {
				if (!alreadyCalled) {
					stopObserving();
				}
			}, timeoutSinceStopParsingDocument);
		}
	}

	/**
	 * 目印となる節が挿入されたら、監視を停止し、{@link checkExistingTarget}を実行する。
	 * @param {MutationRecord[]} mutations - A list of MutationRecord objects.
	 * @param {MutationObserver} observer - The constructed MutationObserver object.
	 */
	function mutationCallback(mutations, observer) {
		for (var mutation of mutations) {
			var target = mutation.target;
			if (target.nodeType === Node.ELEMENT_NODE && isTargetParent(target)) {
				// 子が追加された節が要素節で、かつその節についてisTargetParentが真を返せば
				for (var addedNode of mutation.addedNodes) {
					if (addedNode.nodeType === Node.ELEMENT_NODE && isTarget(addedNode)) {
						// 追加された子が要素節で、かつその節についてisTargetが真を返せば
						observer.disconnect();
						checkExistingTarget(0);
						return;
					}
				}
			}
		}
	}

	/**
	 * {@link startMain}を実行し、スクリプトが開始されていなければ再度実行。
	 * @param {number} count - {@link startMain}を実行した回数。
	 */
	function checkExistingTarget(count) {
		startMain();
		if (!alreadyCalled && count < LIMIT) {
			window.setTimeout(checkExistingTarget, INTERVAL, count + 1);
		}
	}

	/**
	 * 指定した節が存在するか確認し、存在すれば{@link stopObserving}を実行しスクリプトを開始。
	 */
	function startMain() {
		if (!alreadyCalled && existsTarget()) {
			stopObserving();
			main();
		}
	}

	/**
	 * 監視を停止する。
	 */
	function stopObserving() {
		alreadyCalled = true;
		if (observer) {
			observer.disconnect();
		}
		document.removeEventListener('DOMContentLoaded', onDOMContentLoaded);
	}
}

/**
 * prototype汚染が行われる Prototype JavaScript Framework (prototype.js) 1.5.1.1 のバグを修正 (Tampermonkey / Violentmonkey用)。
 */
function fixPrototypeJavaScriptFramework() {
	if (Array.prototype.toJSON) {
		for (var classObject of [Array, String]) {
			delete classObject.prototype.toJSON;
		}
	}
}

/**
 * 国際化・地域化関数などの読み込み、及びECMAScriptとWHATWG仕様のPolyfill
 */
function polyfill() {
	/**
	 * DOM関連のメソッド。
	 */
	var DOMUtils = {
		/**
		 * XMLの特殊文字を文字参照に置換する。
		 * @param {string} str - プレーンな文字列。
		 * @returns {string} HTMLとして扱われる文字列。
		 */
		convertSpecialCharactersToCharacterReferences: function (str) {
			return str.replace(/[&<>"']/g, function (specialCharcter) {
				return '&#x' + specialCharcter.charCodeAt(0).toString(16) + ';'
			});
		},
	};
	window.h = DOMUtils.convertSpecialCharactersToCharacterReferences;

	/**
	 * 以下のような形式の翻訳リソース。すべての言語について、msgidは欠けていないものとする。
	 * {@link Gettext.DEFAULT_LOCALE}のリソースを必ず含む。{@link Gettext.ORIGINAL_LOCALE}のリソースは無視される。
	 * {
	 *     'IETF言語タグ': {
	 *         '翻訳前 (msgid)': '翻訳後 (msgstr)',
	 *         ……
	 *     },
	 *     ……
	 * }
	 * @typedef {Object} LocalizedTexts
	 */

	/**
	 * i18n。
	 * @version 2014-07-10
	 */
	window.Gettext = {
		/**
		 * 翻訳対象文字列 (msgid) の言語。IETF言語タグの「language」サブタグ。
		 * @constant {string}
		 */
		ORIGINAL_LOCALE: 'ja',

		/**
		 * クライアントの言語の翻訳リソースが存在しないとき、どの言語に翻訳するか。IETF言語タグの「language」サブタグ。
		 * @constant {string}
		 */
		DEFAULT_LOCALE: 'en',

		/**
		 * 翻訳リソースを追加する。
		 * @param {LocalizedTexts} localizedTexts
		 */
		setLocalizedTexts: function (localizedTexts) {
			this.multilingualLocalizedTexts = localizedTexts;
		},

		/**
		 * クライアントの言語を設定する。
		 * @param {string} clientLang - IETF言語タグ（「language」と「language-REGION」にのみ対応）。
		 */
		setLocale: function (clientLang) {
			var splitedClientLang = clientLang.split('-', 2);
			this.language = splitedClientLang[0].toLowerCase();
			this.langtag = this.language + (splitedClientLang[1] ? '-' + splitedClientLang[1].toUpperCase() : '');
			if (this.language === 'ja') {
				// ja-JPをjaと同一視
				this.langtag = this.language;
			}
		},

		/**
		 * テキストをクライアントの言語に変換する。
		 * @param {string} message - 翻訳前。
		 * @returns {string} 翻訳後。
		 */
		gettext: function (message) {
			// クライアントの言語が翻訳元の言語なら、そのまま返す
			return this.langtag === this.ORIGINAL_LOCALE && message
					// クライアントの言語の翻訳リソースが存在すれば、それを返す
					|| this.langtag in this.multilingualLocalizedTexts && this.multilingualLocalizedTexts[this.langtag][message]
					// 地域下位タグを取り除いた言語タグの翻訳リソースが存在すれば、それを返す
					|| this.language in this.multilingualLocalizedTexts && this.multilingualLocalizedTexts[this.language][message]
					// 既定言語の翻訳リソースが存在すれば、それを返す
					|| this.DEFAULT_LOCALE in this.multilingualLocalizedTexts && this.multilingualLocalizedTexts[this.DEFAULT_LOCALE][message]
					// そのまま返す
					|| message;
		},

		/**
		 * クライアントの言語。{@link Gettext.setLocale}から変更される。
		 * @type {string}
		 * @access private
		 */
		langtag: 'ja',

		/**
		 * クライアントの言語のlanguage部分。{@link Gettext.setLocale}から変更される。
		 * @type {string}
		 * @access private
		 */
		language: 'ja',

		/**
		 * 翻訳リソース。{@link Gettext.setLocalizedTexts}から変更される。
		 * @type {LocalizedTexts}
		 * @access private
		 */
		multilingualLocalizedTexts: {},
	};
	window._ = Gettext.gettext.bind(Gettext);

	// Polyfill for Opera and Google Chrome
	if (!('startsWith' in String.prototype)) {
		/**
		 * Determines whether a string begins with the characters of another string, returning true or false as appropriate.
		 * @param {string} searchString - The characters to be searched for at the start of this string.
		 * @param {number} [position=0] - The position in this string at which to begin searching for searchString.
		 * @returns {boolean}
		 * @see {@link http://people.mozilla.org/~jorendorff/es6-draft.html#sec-string.prototype.startswith 21.1.3.18 String.prototype.startsWith (searchString [, position ] )}
		 * @see {@link https://developer.mozilla.org/docs/Web/JavaScript/Reference/Global_Objects/String/startsWith String.startsWith - JavaScript | MDN}
		 * @version polyfill-2013-11-05
		 * @name String.prototype.startsWith
		 */
		Object.defineProperty(String.prototype, 'startsWith', {
			writable: true,
			enumerable: false,
			configurable: true,
			value: function (searchString) {
				var position = arguments[1];
				return this.indexOf(searchString, position) === Math.max(Math.floor(position) || 0, 0);
			},
		});
	}

	if (typeof URLSearchParams === 'undefined') {
		/** @namespace URL */
		/**
		 * @param {string} input
		 * @returns {Array.<Array.<string>>} List of name-value pairs where both name and value hold a string.
		 * @see [application/x-www-form-urlencoded – URL Standard]{@link https://url.spec.whatwg.org/#concept-urlencoded-string-parser}
		 * @memberof URL
		 * @function
		 * @private
		 */
		var parseXWWWFormUrlencoded = function (input) {
			var output = [];
			for (var bytes of input.split('&')) {
				if (bytes !== '') {
					bytes = bytes.replace(/\+/g, ' ');
					var index = bytes.indexOf('=');
					var name, value;
					if (index !== -1) {
						name = bytes.slice(0, index);
						value = bytes.slice(index + 1);
					} else {
						name = bytes;
						value = '';
					}
					output.push([decodeURIComponent(name), decodeURIComponent(value)]);
				}
			}
			return output;
		};
		/**
		 * @param {string} input - A byte sequence.
		 * @returns {string}
		 * @see [application/x-www-form-urlencoded – URL Standard]{@link https://url.spec.whatwg.org/#concept-urlencoded-byte-serializer}
		 * @memberof URL
		 * @function
		 * @private
		 */
		var serializeXWWWFormUrlencodedByte = function (input) {
			return encodeURIComponent(input).replace(/%20/g, '+').replace(/[!~'()]+/g, escape);
		};
		/**
		 * @param {Array.<Array.string>} pairs - List of name-value pairs pairs.
		 * @returns {string}
		 * @see [application/x-www-form-urlencoded – URL Standard]{@link https://url.spec.whatwg.org/#concept-urlencoded-serializer}
		 * @memberof URL
		 * @function
		 * @private
		 */
		var serializeXWWWFormUrlencodedString = function (pairs) {
			return pairs.map(function (pair) {
				return serializeXWWWFormUrlencodedByte(pair[0]) + '=' + serializeXWWWFormUrlencodedByte(pair[1]);
			}).join('&');
		};

		var _URLSearchParams_list = new WeakMap();
		var _URLSearchParams_urlObjects = new WeakMap();

		/**
		 * A URLSearchParams object has an associated list of name-value pairs, which is initially empty.
		 * @param {(string|URLSearchParams)} [init=""]
		 * @see [URLSearchParams Interface – URL Standard]{@link https://url.spec.whatwg.org/#interface-urlsearchparams}
		 * @version polyfill-2015-08-10
		 * @license CC-BY-4.0
		 * @constructor URLSearchParams
		 */
		Object.defineProperty(window, 'URLSearchParams', {
			writable: true,
			enumerable: false,
			configurable: true,
			value: function (init) {
				if (init === undefined) {
					init = '';
				} else if (!(init instanceof URLSearchParams) && typeof init !== 'string') {
					init = String(init);
				}

				/**
				 * A URLSearchParams object has an associated list of name-value pairs, which is initially empty.
				 * @type {Array.<Array.<string, string>>}
				 * @private
				 * @memberof URLSearchParams#
				 */
				var list = [];
				if (init instanceof URLSearchParams) {
					for (var pair of _URLSearchParams_list.get(init)) {
						list.push(pair[0], pair[1]);
					}
				} else if (init !== '') {
					list = parseXWWWFormUrlencoded(init);
				}
				_URLSearchParams_list.set(this, list);

				/**
				 * A URLSearchParams object has an associated list of zero or more url objects, which is initially empty. 
				 * @type {Set.<Array.<string, string>>}
				 * @private
				 * @member URLSearchParams#urlObjects
				 */
				_URLSearchParams_urlObjects.set(this, new Set());
			}
		});

		/**
		 * @see [URLSearchParams Interface – URL Standard]{@link https://url.spec.whatwg.org/#concept-URLSearchParams-update}
		 * @param {(URL|HTMLAnchorElement|HTMLAreaElement|Location)} [excluded]
		 * @function
		 * @private
		 * @function URLSearchParams#runQueryUpdateSteps
		 */
		var _URLSearchParams_runQueryUpdateSteps = function (excluded) {
			var list = _URLSearchParams_list.get(this);
			var search = excluded
					? excluded.search
					: (list[0] ? '?' + serializeXWWWFormUrlencodedString(list) : '');
			for (var urlObject of _URLSearchParams_urlObjects.get(this)) {
				if (urlObject !== excluded) {
					urlObject.search = search;
				}
			}
		};

		Object.defineProperties(URLSearchParams.prototype, /** @lends URLSearchParams# */ {
			/**
			 * Append a new name-value pair whose name is name and value is value, to the list of name-value pairs.
			 * @param {string} name
			 * @param {string} value
			 * @function
			 */
			append: {
				writable: true,
				enumerable: false,
				configurable: true,
				value: function (name, value) {
					if (arguments.length < 2) {
						throw new TypeError('Failed to execute \'append\' on \'URLSearchParams\': 2 argument required, but only ' + arguments.length + ' present.');
					}
					_URLSearchParams_list.get(this).push([String(name), String(value)]);
					_URLSearchParams_runQueryUpdateSteps.call(this);
				}
			},
			/**
			 * Remove all name-value pairs whose name is name.
			 * @param {string} name
			 * @function
			 */
			'delete': {
				writable: true,
				enumerable: false,
				configurable: true,
				value: function (name) {
					if (arguments.length < 1) {
						throw new TypeError('Failed to execute \'delete\' on \'URLSearchParams\': 1 argument required, but only ' + arguments.length + ' present.');
					}
					var list = _URLSearchParams_list.get(this);
					for (var i = 0, l = list.length; i < l; i++) {
						if (list[i][0] === name) {
							list.splice(i, 1);
							i--;
							l--;
						}
					}
					_URLSearchParams_runQueryUpdateSteps.call(this);
				}
			},
			/**
			 * Return the value of the first name-value pair whose name is name, and null if there is no such pair.
			 * @param {string} name
			 * @returns {?string}
			 * @function
			 */
			get: {
				writable: true,
				enumerable: false,
				configurable: true,
				value: function (name) {
					if (arguments.length < 1) {
						throw new TypeError('Failed to execute \'get\' on \'URLSearchParams\': 1 argument required, but only ' + arguments.length + ' present.');
					}
					for (var pair of _URLSearchParams_list.get(this)) {
						if (pair[0] === name) {
							return pair[1];
						}
					}
					return null;
				}
			},
			/**
			 * Return the values of all name-value pairs whose name is name, in list order, and the empty sequence otherwise.
			 * @param {string} name
			 * @returns {string[]}
			 * @function
			 */
			getAll: {
				writable: true,
				enumerable: false,
				configurable: true,
				value: function (name) {
					if (arguments.length < 1) {
						throw new TypeError('Failed to execute \'getAll\' on \'URLSearchParams\': 1 argument required, but only ' + arguments.length + ' present.');
					}
					var values = [];
					for (var pair of _URLSearchParams_list.get(this)) {
						if (pair[0] === name) {
							values.push(pair[1]);
						}
					}
					return values;
				}
			},
			/**
			 * If there are any name-value pairs whose name is name, set the value of the first such name-value pair to value and remove the others.
			 * Otherwise, append a new name-value pair whose name is name and value is value, to the list of name-value pairs.
			 * @param {string} name
			 * @param {string} value
			 * @function
			 */
			set: {
				writable: true,
				enumerable: false,
				configurable: true,
				value: function (name, value) {
					if (arguments.length < 2) {
						throw new TypeError('Failed to execute \'set\' on \'URLSearchParams\': 2 argument required, but only ' + arguments.length + ' present.');
					}
					var list = _URLSearchParams_list.get(this);
					var flag;
					for (var i = 0, l = list.length; i < l; i++) {
						if (list[i][0] === name) {
							if (flag) {
								list.splice(i, 1);
								i--;
								l--;
							} else {
								list[i][1] = String(value);
								flag = true;
							}
						}
					}
					if (!flag) {
						list.push([String(name), String(value)]);
					}
					_URLSearchParams_runQueryUpdateSteps.call(this);
				}
			},
			/**
			 * Return true if there is a name-value pair whose name is name, and false otherwise.
			 * @param {string} name
			 * @returns {boolean}
			 * @function
			 */
			has: {
				writable: true,
				enumerable: false,
				configurable: true,
				value: function (name) {
					if (arguments.length < 1) {
						throw new TypeError('Failed to execute \'has\' on \'URLSearchParams\': 1 argument required, but only ' + arguments.length + ' present.');
					}
					for (var pair of _URLSearchParams_list.get(this)) {
						if (pair[0] === name) {
							return true;
						}
					}
					return false;
				}
			},
			/**
			 * Return the serialization of the URLSearchParams object's associated list of name-value pairs.
			 * @returns {string}
			 * @function
			 */
			toString: {
				writable: true,
				enumerable: false,
				configurable: true,
				value: function () {
					return serializeXWWWFormUrlencodedString(_URLSearchParams_list.get(this));
				}
			},
			/**
			 * @returns {Iterator.<Array.<string, string>>}
			 * @function
			 */
			entries: {
				writable: true,
				enumerable: false,
				configurable: true,
				value: function* () {
					for (var pair of _URLSearchParams_list.get(this)) {
						yield [pair[0], pair[1]];
					}
				}
			},
			/**
			 * @returns {Iterator.<string>}
			 * @function
			 */
			keys: {
				writable: true,
				enumerable: false,
				configurable: true,
				value: function* () {
					for (var pair of _URLSearchParams_list.get(this)) {
						yield pair[0];
					}
				}
			},
			/**
			 * @returns {Iterator.<string>}
			 * @function
			 */
			values: {
				writable: true,
				enumerable: false,
				configurable: true,
				value: function* () {
					for (var pair of _URLSearchParams_list.get(this)) {
						yield pair[1];
					}
				}
			},
		});
		/**
		 * The value pairs to iterate over are the list name-value pairs with the key being the name and the value the value. 
		 * @returns {Iterator.<Array.<string, string>>}
		 * @function URLSearchParams#@@iterator
		 */
		Object.defineProperty(URLSearchParams.prototype, Symbol.iterator, {
			writable: true,
			enumerable: false,
			configurable: true,
			value: function* () {
				for (var pair of _URLSearchParams_list.get(this)) {
					yield [pair[0], pair[1]];
				}
			}
		});

		/** @namespace URLUtils */
		var _URLUtils_queryObject = new WeakMap();
		/**
		 * @member {URLSearchParams} URLUtilsSearchParams#searchParams
		 */
		for (var interfaceObject of [URL, HTMLAnchorElement, HTMLAreaElement]) {
			Object.defineProperty(interfaceObject.prototype, 'searchParams', {
				enumerable: false,
				configurable: true,
				get: function () {
					var queryObject = _URLUtils_queryObject.get(this);
					if (!queryObject) {
						// If query object is null,
						// set query object to a new URLSearchParams object using query, 
						queryObject = new URLSearchParams(this.search.replace('?', ''));
						_URLUtils_queryObject.set(this, queryObject);
						// and then append the context object to query object’s list of url objects.
						_URLSearchParams_urlObjects.get(queryObject).add(this);
					}
					return queryObject;
				},
				set: function (object) {
					if (!(object instanceof Object)) {
						throw new TypeError('Value being assigned to ' + Object.prototype.toString.call(this).match(/ (.+)\]/)[1] + '.searchParams is not an object.');
					} else if (!(object instanceof URLSearchParams)) {
						throw new TypeError('Value being assigned to ' + Object.prototype.toString.call(this).match(/ (.+)\]/)[1] + '.searchParams does not implement interface URLSearchParams.');
					}
					var queryObject = _URLUtils_queryObject.get(this);
					// Remove the context object from query object’s list of url objects.
					if (queryObject) {
						_URLSearchParams_urlObjects.get(queryObject).delete(this);
					}
					// Append the context object to object’s list of url objects.
					_URLSearchParams_urlObjects.get(object).add(this);
					// Set query object to object.
					_URLUtils_queryObject.set(this, object);
				}
			});
		}
		/**
		 * @private
		 * @function URLUtils#updateSearchParams
		 */
		var _URLUtils_updateSearchParams = function () {
			var searchParams = this.searchParams;
			var search = this.search;
			_URLSearchParams_list.set(searchParams, search ? parseXWWWFormUrlencoded(search.replace('?', '')) : []);
			_URLSearchParams_runQueryUpdateSteps.call(searchParams, this);
		};
		new MutationObserver(function (mutations) {
			for (var record of mutations) {
				var target = record.target;
				var name = target.localName;
				if (name === 'a' || name === 'area') {
					_URLUtils_updateSearchParams.call(target);
				}
			}
		}).observe(document, {
			attributeFilter: ['href'],
			subtree: true,
		});
	}

	if (!('@@iterator' in NodeList.prototype) && !(Symbol.iterator in NodeList.prototype)) {
		/** @version polyfill-2014-12-07 */
		Object.defineProperties(NodeList.prototype, /** @lends NodeList# */ {
			/**
			 * @returns {Iterator.<Array.<number, Node>>}
			 * @function
			 */
			entries: {
				writable: true,
				enumerable: false,
				configurable: true,
				value: function* () {
					for (var i = 0, l = this.length; i < l; i++) {
						yield [i, this[i]];
					}
				}
			},
			/**
			 * @returns {Iterator.<number>}
			 * @function
			 */
			keys: {
				writable: true,
				enumerable: false,
				configurable: true,
				value: function* () {
					for (var i = 0, l = this.length; i < l; i++) {
						yield i;
					}
				}
			},
			/**
			 * @returns {Iterator.<Node>}
			 * @function
			 */
			values: {
				writable: true,
				enumerable: false,
				configurable: true,
				value: function* () {
					for (var i = 0, l = this.length; i < l; i++) {
						yield this[i];
					}
				}
			},
		});
		/**
		 * @returns {Iterator.<Node>}
		 * @function NodeList#@@iterator
		 */
		Object.defineProperty(NodeList.prototype, Symbol.iterator, {
			writable: true,
			enumerable: false,
			configurable: true,
			value: function* () {
				for (var i = 0, l = this.length; i < l; i++) {
					yield this[i];
				}
			}
		});
	}
}

})();
