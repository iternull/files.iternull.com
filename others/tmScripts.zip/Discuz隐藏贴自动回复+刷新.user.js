// ==UserScript==
// @id             f70372fe-b728-494a-b889-90e810d9345b@scriptish
// @name           Discuz隐藏贴自动回复+刷新
// @version        1.4.0.1
// @namespace      f70372fe-b728-494a-b889-90e810d9345b@scriptish
// @include        http://*/*
// @run-at         document-end
// @license     GPL version 3
// @encoding    utf-8
// @description    This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// ==/UserScript==
