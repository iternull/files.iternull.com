// ==UserScript==
// @name         Export Weibo Album to List or Image
// @namespace    https://greasyfork.org/zh-CN/users/10666-sbdx
// @version      0.2.20150622
// @description  批量导出新浪微博相册图片，用于保存、下载
// @author       sbdx
// @match        http://weibo.com/*
// match        http://weibo.com/p/*/album*
// @grant        none
// @require  	 http://libs.useso.com/js/jquery/1.9.1/jquery.min.js
// ==/UserScript==
/*
@echo off
Rem wget批量下载并且重命名 批处理文件
setlocal enabledelayedexpansion
set /a num=0
FOR /F %%i in (URL.txt) do (
 set /a num+=1
 title !num!
 wget -c -q %%i -O !num!.jpg
)
*/ 
jQuery(function(){
    AlbumID=$CONFIG['page_id'];
    page=0;hasNext=true;lastMid='';//全局变量
    total_pic=0;	//图片总数
    boolShowPicOrLink=true;	//显示图片或地址
    $PICS=[];
    var nw;
    //$.ajaxSetup({async:false,cache:false});
    function ProcessAlbum()
    {
        page++;
        console.log('第'+page+'页');
        url='http://photo.weibo.com/page/waterfall?ajwvr=6&filter=wbphoto%7C%7C%7Cv6&page='+page+'&count=20&module_id=profile_photo&oid='+AlbumID+'&uid=&lastMid='+lastMid+'&lang=zh-cn&_t=1&callback=?';
        $.getJSON(url,function(d){
            /*
            console.log('已返回第'+page+'页数据：');
            console.log('URL:'+url);
            */
            if(1===page){total_pic=$(d.data.html[0]).find('ul li:eq(0) em').text();nw.document.writeln('图片总数：'+total_pic+'<br>');}
            if(d.data.html.length===0)
            {
                hasNext=false;
                nw.document.title='载入完毕！';
                return;
            }
            else
            {
                lastMid=d.data.lastMid;
                source=d.data.html.join(' ');
                $(source).find('img.photo_pic').each(function(i){
                    //console.log(this.src.replace('cmw218','large'));
                    picurl=this.src.replace(/(http:\/\/.+?\/)(.+?)(\/.*)/i,'$1large$3');
                    if(boolShowPicOrLink)
                    {
                        nw.document.writeln('<img src="'+picurl+'" border="0" /><br>');
                    }
                    else
                    {
                        nw.document.writeln('<a href="'+picurl+'" target="_blank">'+picurl+'</a><br>');
                    }
                    //console.log(picurl);
                });
                ProcessAlbum();
            }
        });
    }
    function btnOnClick()
    {
        page=0;
        if($('.num.S_txt1:eq(0)').length==0){alert('请等待页面加载完毕再执行！');return;}
        if($('.num.S_txt1:eq(0)').text()>50)
        {
            boolShowPicOrLink=confirm("图片数量过多，请选择显示 图片 或 连接！\n是 - 显示图片 否 - 显示连接");
        }
        nw=window.open('','output');
        nw.document.title='正在载入......';
        ProcessAlbum();
    }
    function ShowLargeImageInSinglePage()
    {
        $('.media_box img').each(function(i){this.src=this.src.replace(/(http:\/\/.+?\/)(.+?)(\/.*)/i,'$1large$3')})
    }
    
    $("body").append("<div id='sbdx_tools_getAllImage' style='position:absolute;right:10px;top:100px;'><button>显示相册全部图片</button></div>");$("#sbdx_tools_getAllImage").on("click",btnOnClick);
    $("body").append("<div id='sbdx_tools_for9' style='position:absolute;right:10px;top:130px;'><button>单页显示九宫格大图</button></div>");$("#sbdx_tools_for9").on("click",ShowLargeImageInSinglePage);
    
    $(window).scroll(function(){$("div[id^=sbdx]").each(function(i){$(this).offset({top:$(document).scrollTop()+100+i*30})});});
});