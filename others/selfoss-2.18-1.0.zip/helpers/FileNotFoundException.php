<?php

namespace helpers;

class FileNotFoundException extends \Exception {
}
