MCU: ESP8266EX
Flash memory: 1 MB
