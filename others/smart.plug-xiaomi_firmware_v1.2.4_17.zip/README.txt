MCU: Marvell 88MW300
Flash memory: 1MB
