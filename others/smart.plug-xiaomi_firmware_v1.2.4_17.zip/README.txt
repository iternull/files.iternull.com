MCU: Marvell 88MW300
Flash memory: 1MB
App Name: �׼�
App Link: https://home.mi.com/index.html
