Adobe CC 2018 Download
https://helpx.adobe.com/download-install/kb/creative-cloud-apps-download.html

AMTEmu v.0.9.2 Download
https://www.reddit.com/r/MSToolkit/comments/7bscny/amtemu_092exe_amtemuv081macpainter_universal/
